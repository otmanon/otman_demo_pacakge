

def demo_print():
    print("Hello from Otman's demo package")